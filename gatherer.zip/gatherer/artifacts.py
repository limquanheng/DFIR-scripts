__author__ = 'spydir'


files = [
         {"name":"Registry","path":"/Windows/System32/config/SAM"},
         {"name":"Registry","path":"/Windows/System32/config/security"},
         {"name":"Registry","path":"/Windows/System32/config/software"},
         {"name":"Registry","path":"/Windows/System32/config/SYSTEM"},
         {"name":"MFT","path":"/$MFT"}
        ]


directories = [
                {'name':"evtx",'path':"/Windows/System32/Winevt/logs"}
              ]